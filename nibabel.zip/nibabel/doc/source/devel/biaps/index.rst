.. _biap_list:

#####
BIAPs
#####

niBabel Increased Awesomeness Proposals (BIAPs) document major changes or
proposals.

.. toctree::
   :maxdepth: 1

   biap_0000
   biap_0001
   biap_0002
   biap_0003
   biap_0004
   biap_0005
   biap_0006
   biap_0007
   biap_0008

.. toctree::
   :hidden:

   biap_template
